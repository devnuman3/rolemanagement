const express = require('express');
const routeController = require('../controllers/role.controller')
const roleRouter = express.Router();

roleRouter.route('/addrole').post(routeController.createRole)

module.exports = roleRouter