const express = require('express');
const userController = require('../controllers/user.controller')
const userRouter = express.Router();

userRouter.route('/adduser').post(userController.createUser)

userRouter.route('/user/:id').get(userController.getUser).patch(userController.updateUser).delete(userController.deleteUser)

module.exports = userRouter