const mongoose = require('mongoose')
const bcrypt = require('bcrypt')
const roleController = require('../controllers/role.controller')
const ObjectId = mongoose.Types.ObjectId;

const userSchema = mongoose.Schema({
    username: {
        type:String,
        required: [true, 'Username is required']
    },
    email:{
        type:String,
        required: [true, 'Email is required']
    },
    password:{
        type:String,
        required: [true, 'Password is required']
    },
    image: {
      type:String,
        default: '../public/img/user.png'
    },
    roleId: {
        type: mongoose.Types.ObjectId,
        default: ObjectId('632891bd4885d285d3e50d06'),
        ref: 'role',
    },
    isActive:{
        type:Boolean,
        default:true,
    },
    isDeleted:{
        type:Boolean,
        default:false
    }

}, { timestamps: true })


// userSchema.pre('save',async (req,res,next)=>{
//     console.log(this)
//     // const salt = await bcrypt.genSalt(12);
//     // const hashPassword = await bcrypt.hash(password, salt);
//     // req.body.password = hashPassword;
//
// })

module.exports = mongoose.model('user', userSchema);
