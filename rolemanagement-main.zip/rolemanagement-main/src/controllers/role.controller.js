const Role = require('../models/role.model')

module.exports.createRole=async (req,res,next)=>{
    try{
        const role = await Role.create(req.body)
        res.status(201).json({
            message:'Role Created Successfully',
            data: role
        })
    }catch(err){
        console.log('Error', err);
        res.status(501).json({
            message:'Internal Server Error'
        })
    }
}