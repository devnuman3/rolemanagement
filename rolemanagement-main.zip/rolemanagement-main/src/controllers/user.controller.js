const { findByIdAndUpdate, findById } = require('../models/user.model');
const User = require('../models/user.model');
const bcrypt = require('bcrypt')

module.exports.createUser=async (req,res,next)=>{
    try{
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash(req.body.password, salt);
      req.body.password = hashedPassword

        const user = await User.create(req.body);
        res.status(201).json({
            message:'User Created Successfully',
            data:user
        })
    }catch(err){
        console.log('Error', err);
        res.status(501).json({
            message:'Internal Server Error'
        })
    }
}

module.exports.getUser=(req,res,next)=>{
    try{
        const user_id = req.params.id;
        const user = findById(user_id);
        res.status(200).json({
            message:'Success',
            data:user
        })
    }catch(err){
        console.log('Error', err);
        res.status(501).json({
            message:'Internal Server Error'
        })
    }
}

module.exports.updateUser=async (req,res,next)=>{
    try{
       const user_id = req.params.id;
        await findByIdAndUpdate(user_id,req.body)
        res.status(204).json({
            message:'Updated Successfully'
        })
        
    }catch(err){
        console.log('Error', err);
        res.status(501).json({
            message:'Internal Server Error'
        })
    }
}

module.exports.deleteUser=async (req,res,next)=>{
    try{
        
        const user_id = req.params.id;
        await User.findByIdAndUpdate(user_id,{isDeleted:true})
        res.status(200).json({
            message:'Successfully deleted'
        })

    }catch(err){
        console.log('Error', err);
        res.status(501).json({
            message:'Internal Server Error'
        })
    }
}