require('dotenv').config()
const express = require('express')
const mongoose = require('mongoose')
const userRouter = require('./src/routes/user.routes')
const roleRouter = require('./src/routes/role.routes')

const app = express();
app.use(express.json())


mongoose.connect(process.env.MONGO_URI,{
    useNewUrlParser:true
}).then(()=>{
    console.log('Connected');
}).catch(err=>{
    console.log('Error ', err);
})

const port = process.env.PORT || 3000

app.use('/api/v1',userRouter)
app.use('/api/v1',roleRouter)

app.listen(port,()=>{
    console.log(`Server Running on Port ${process.env.PORT}`);
})